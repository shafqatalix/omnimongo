import { app as a, BrowserWindow as b, ipcMain as f } from "electron";
import { fileURLToPath as v } from "node:url";
import o from "node:path";
import i from "node:fs";
import L from "node:os";
import { MongoClient as F, ObjectId as E } from "mongodb";
const R = /* @__PURE__ */ new Map(), I = (e) => {
  var n;
  return ((n = e == null ? void 0 : e.split("/").pop()) == null ? void 0 : n.split("?")[0]) || "";
};
async function P(e) {
  if (!e) throw new Error("MongoDB URI is required");
  let n = R.get(e);
  return n || (n = new F(e), await n.connect(), R.set(e, n)), n;
}
function N(e) {
  return e instanceof E ? e.toHexString() : typeof e == "string" && E.isValid(e) ? e : JSON.stringify(e);
}
async function V(e) {
  const n = await P(e), t = I(e);
  return (await n.db(t).listCollections().toArray()).map((S) => S.name).sort();
}
async function x(e, n, t) {
  const d = await P(e), g = I(e), A = await d.db(g).collection(n).find({}).toArray(), m = /* @__PURE__ */ new Map();
  for (const p of A) {
    const C = p._id ?? p.id, D = N(C), _ = {
      ...p,
      _id: D
      // always a hex string
    };
    let c = "";
    for (const u of t) {
      const r = _[u];
      if (r)
        if (Array.isArray(r)) {
          if (r.length === 0) continue;
          c += `[${u}:${r.join(",")}]`;
        } else
          c += `[${u}:${r}]`;
    }
    c = c.split(" ").join("").toLocaleLowerCase(), m.set(c, _);
  }
  return console.log(`Fetched ${m.size} docs from ${g}.${n}`), m;
}
const U = o.dirname(v(import.meta.url));
process.env.APP_ROOT = o.join(U, "..");
const y = process.env.VITE_DEV_SERVER_URL, $ = o.join(process.env.APP_ROOT, "dist-electron"), j = o.join(process.env.APP_ROOT, "dist");
process.env.VITE_PUBLIC = y ? o.join(process.env.APP_ROOT, "public") : j;
const T = o.join($, "preload.js");
let s;
function w() {
  console.log("Preload path:", T), s = new b({
    width: 1200,
    height: 800,
    icon: o.join(process.env.VITE_PUBLIC, "icon-256x256.ico"),
    webPreferences: {
      preload: T,
      contextIsolation: !0,
      nodeIntegration: !1,
      sandbox: !1
    }
  }), s.webContents.on("did-finish-load", () => {
    s == null || s.webContents.send("main-process-message", (/* @__PURE__ */ new Date()).toLocaleString());
  }), y ? (s.loadURL(y), s.webContents.openDevTools()) : s.loadFile(o.join(j, "index.html"));
}
a.on("window-all-closed", () => {
  process.platform !== "darwin" && (a.quit(), s = null);
});
a.on("activate", () => {
  b.getAllWindows().length === 0 && w();
});
a.whenReady().then(w);
const h = o.join(L.homedir(), ".omnimongo"), l = o.join(h, "settings.json"), O = {
  connections: {
    localhost: "mongodb://localhost:27017/mydb"
  }
};
function M() {
  try {
    i.existsSync(h) || i.mkdirSync(h, { recursive: !0 }), i.existsSync(l) || (i.writeFileSync(l, JSON.stringify(O, null, 2), "utf-8"), console.log("Created settings file at:", l));
  } catch (e) {
    console.error("Failed to initialize settings:", e);
  }
}
a.whenReady().then(() => {
  M(), w();
});
f.handle("settings:read", async () => {
  try {
    const e = i.readFileSync(l, "utf-8");
    return JSON.parse(e);
  } catch (e) {
    return console.error("Failed to read settings:", e), O;
  }
});
f.handle("settings:write", async (e, n) => {
  try {
    return i.writeFileSync(l, JSON.stringify(n, null, 2), "utf-8"), { success: !0 };
  } catch (t) {
    return console.error("Failed to write settings:", t), { success: !1, error: t.message };
  }
});
f.handle("mongo:get-collections", async (e, n) => (console.log({ event: e, url: n }), V(n)));
f.handle("mongo:get-documents", async (e, n, t, d) => (console.log("Fetching documents from:", n, t), x(n, t, d)));
export {
  $ as MAIN_DIST,
  j as RENDERER_DIST,
  y as VITE_DEV_SERVER_URL
};
