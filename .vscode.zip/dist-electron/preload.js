import { contextBridge as t, ipcRenderer as o } from "electron";
console.log("Preload script is running...");
t.exposeInMainWorld("mongo", {
  getCollections: (e) => (console.log("preload:ts: Requesting collections for URL:", e), o.invoke("mongo:get-collections", e)),
  getDocuments: (e, n, r) => (console.log("preload:ts: Requesting documents for:", e, n), o.invoke("mongo:get-documents", e, n, r))
});
t.exposeInMainWorld("settings", {
  read: () => o.invoke("settings:read"),
  write: (e) => o.invoke("settings:write", e)
});
console.log("electronAPI exposed to window");
